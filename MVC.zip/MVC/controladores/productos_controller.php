<?php
 function listar ()
 {
   
 }

function ver ()
{
   
}