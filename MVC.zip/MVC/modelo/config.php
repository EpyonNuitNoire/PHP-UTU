
<?php

    function getConnection() {
       
   }


?>