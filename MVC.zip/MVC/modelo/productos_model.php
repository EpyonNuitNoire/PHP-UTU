<?php

require "config.php";

   
   function getProductos() {
     
      

   }
   function getProducto($id)
   {

     

   }
?>